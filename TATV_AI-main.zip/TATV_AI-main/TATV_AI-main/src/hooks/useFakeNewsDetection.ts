import { useState, useEffect } from 'react';
import { pipeline } from '@huggingface/transformers';

interface DetectionResult {
  label: string;
  score: number;
  isLoading: boolean;
  error: string | null;
}

let modelInstance: any = null;
let modelLoading = false;

export const useFakeNewsDetection = () => {
  const [isModelReady, setIsModelReady] = useState(false);

  useEffect(() => {
    const loadModel = async () => {
      if (modelInstance || modelLoading) return;
      
      try {
        modelLoading = true;
        console.log('Loading fake news detection model...');
        modelInstance = await pipeline(
          'text-classification',
          'mrm8488/bert-tiny-finetuned-fake-news-detection',
          { device: 'wasm' }
        );
        setIsModelReady(true);
        console.log('Model loaded successfully');
      } catch (error) {
        console.error('Error loading model:', error);
      } finally {
        modelLoading = false;
      }
    };

    loadModel();
  }, []);

  const detectFakeNews = async (text: string): Promise<DetectionResult> => {
    if (!modelInstance) {
      return {
        label: 'Model not loaded',
        score: 0,
        isLoading: false,
        error: 'Model is still loading. Please try again.',
      };
    }

    try {
      const result = await modelInstance(text);
      const topResult = Array.isArray(result) ? result[0] : result;
      
      return {
        label: topResult.label,
        score: topResult.score,
        isLoading: false,
        error: null,
      };
    } catch (error) {
      console.error('Error detecting fake news:', error);
      return {
        label: 'Error',
        score: 0,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  };

  return { detectFakeNews, isModelReady };
};
