import { Badge } from "@/components/ui/badge";
import { Bookmark, TrendingUp, Brain, BarChart3, ShieldCheck, PlayCircle, Volume2, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle } from "lucide-react";
import ArticleDialog from "./ArticleDialog";
import { useBookmarks } from "@/contexts/BookmarkContext";
import { generateAISummary, generateAIPrediction } from "@/lib/aiSummary";
import { useFakeNewsDetection } from "@/hooks/useFakeNewsDetection";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface DiscoverNewsCardProps {
  id: string;
  title: string;
  summary: string;
  category: string;
  imageUrl: string;
  verificationScore: number;
  sources: number;
  readTime: string;
  timestamp: string;
  verified: boolean;
  urgent?: boolean;
  trending?: boolean;
  fullContent?: string;
  thumbnail?: string;
}

const DiscoverNewsCard = ({ 
  id,
  title, 
  summary, 
  category,
  imageUrl,
  verificationScore,
  sources,
  readTime,
  timestamp,
  verified,
  urgent = false,
  trending = false,
  fullContent,
  thumbnail
}: DiscoverNewsCardProps) => {
  const { addBookmark, removeBookmark, isBookmarked } = useBookmarks();
  const bookmarked = isBookmarked(id);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [showAISummary, setShowAISummary] = useState(false);
  const [showAIPrediction, setShowAIPrediction] = useState(false);
  const [showCredibility, setShowCredibility] = useState(false);
  const [quickCheck, setQuickCheck] = useState<{ label: string; score: number } | null>(null);
  const [deepAnalysis, setDeepAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { detectFakeNews, isModelReady } = useFakeNewsDetection();

  const handleBookmarkToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (bookmarked) {
      removeBookmark(id);
    } else {
      addBookmark({
        id,
        title,
        summary,
        category,
        imageUrl,
        verificationScore,
        sources,
        readTime,
        timestamp,
        verified,
        urgent,
        trending
      });
    }
  };

  const handlePlayVideo = (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log("Playing AI explainer video for:", title);
  };

  const handleTextToSpeech = (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log("Starting text-to-speech for:", title);
  };

  const handleCredibilityCheck = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowCredibility(!showCredibility);
    
    if (!showCredibility && !quickCheck && !deepAnalysis) {
      setIsAnalyzing(true);
      
      // Quick browser-based check
      if (isModelReady) {
        try {
          const quickResult = await detectFakeNews(`${title}. ${summary}`);
          if (!quickResult.error) {
            setQuickCheck({ label: quickResult.label, score: quickResult.score });
          } else {
            toast.error("Quick check unavailable: " + quickResult.error);
          }
        } catch (error) {
          console.error("Quick check error:", error);
        }
      }

      // Deep AI analysis
      try {
        const { data, error } = await supabase.functions.invoke('analyze-news-credibility', {
          body: { 
            title, 
            content: fullContent || summary,
            category 
          }
        });

        if (error) throw error;
        setDeepAnalysis(data.analysis);
      } catch (error) {
        console.error("Deep analysis error:", error);
        toast.error("Deep analysis failed. Please try again.");
      } finally {
        setIsAnalyzing(false);
      }
    }
  };

  return (
    <>
      <div 
        className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 group cursor-pointer"
        onClick={() => setDialogOpen(true)}
      >
        {/* Image Section */}
        <div className="relative">
          <img 
            src={imageUrl} 
            alt={title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          
          {/* Overlays */}
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <Badge className="bg-card/90 text-foreground border-0 backdrop-blur-sm capitalize">
              {category}
            </Badge>
            {trending && (
              <Badge className="bg-orange-500/90 text-white border-0 backdrop-blur-sm">
                <TrendingUp className="w-3 h-3 mr-1" />
                Trending
              </Badge>
            )}
            {urgent && (
              <Badge className="bg-red-500/90 text-white border-0 backdrop-blur-sm">
                Breaking
              </Badge>
            )}
          </div>
          
          <div className="absolute top-3 right-3">
            <div className="bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              <span className="text-xs font-semibold">{verificationScore}%</span>
            </div>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            className={`absolute bottom-3 right-3 bg-white/90 hover:bg-white backdrop-blur-sm ${bookmarked ? 'text-brand-electric' : 'text-muted-foreground'}`}
            onClick={handleBookmarkToggle}
          >
            <Bookmark className="w-4 h-4" fill={bookmarked ? "currentColor" : "none"} />
          </Button>
        </div>

        {/* Content Section */}
        <div className="p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-muted-foreground">{timestamp}</span>
          </div>

          <h3 className="font-semibold text-lg mb-2 line-clamp-2 group-hover:text-brand-electric transition-colors">
            {title}
          </h3>
          
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {summary}
          </p>

          <div className="flex items-center text-xs text-muted-foreground mb-4 gap-3">
            <span>{sources} sources</span>
            <span>•</span>
            <span>{readTime} read</span>
          </div>

          {/* AI Features */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Button 
                size="sm" 
                variant="outline"
                className="flex-1 text-xs"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowAISummary(!showAISummary);
                }}
              >
                <Brain className="w-3 h-3 mr-1" />
                AI Summary
              </Button>
              <Button 
                size="sm" 
                variant="outline"
                className="flex-1 text-xs"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowAIPrediction(!showAIPrediction);
                }}
              >
                <BarChart3 className="w-3 h-3 mr-1" />
                Prediction
              </Button>
            </div>

            {showAISummary && (
              <div className="p-3 rounded-lg bg-muted/50 border animate-in fade-in-50 slide-in-from-top-2">
                <h4 className="font-semibold text-sm mb-2 flex items-center">
                  <Brain className="w-3 h-3 mr-2 text-brand-electric" />
                  AI Summary
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {generateAISummary(title, fullContent)}
                </p>
                {thumbnail && (
                  <img 
                    src={thumbnail} 
                    alt="Article thumbnail" 
                    className="w-full h-32 object-cover rounded-lg mt-2"
                  />
                )}
              </div>
            )}

            {showAIPrediction && (
              <div className="p-3 rounded-lg bg-muted/50 border animate-in fade-in-50 slide-in-from-top-2">
                <h4 className="font-semibold text-sm mb-2 flex items-center">
                  <BarChart3 className="w-3 h-3 mr-2 text-brand-electric" />
                  AI Prediction
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {generateAIPrediction(title, category, fullContent)}
                </p>
              </div>
            )}

            <Button 
              size="sm" 
              variant="outline"
              className="w-full text-xs"
              onClick={handleCredibilityCheck}
              disabled={isAnalyzing}
            >
              {isAnalyzing ? (
                <Loader2 className="w-3 h-3 mr-1 animate-spin" />
              ) : (
                <ShieldCheck className="w-3 h-3 mr-1" />
              )}
              Credibility Analysis
            </Button>

            {showCredibility && (
              <div className="p-3 rounded-lg bg-muted/50 border animate-in fade-in-50 slide-in-from-top-2 space-y-3">
                <h4 className="font-semibold text-sm mb-2 flex items-center">
                  <ShieldCheck className="w-3 h-3 mr-2 text-brand-electric" />
                  Credibility Analysis
                </h4>

                {isAnalyzing ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-5 h-5 animate-spin text-brand-electric" />
                    <span className="ml-2 text-xs text-muted-foreground">Analyzing credibility...</span>
                  </div>
                ) : (
                  <>
                    {/* Quick ML Check */}
                    {quickCheck && (
                      <div className="space-y-2 text-xs pb-3 border-b">
                        <p className="font-medium">⚡ Quick Check (Browser ML)</p>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Classification</span>
                          <span className={`font-bold ${quickCheck.label.toLowerCase().includes('fake') ? 'text-red-500' : 'text-green-500'}`}>
                            {quickCheck.label}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Confidence</span>
                          <span className="font-bold">{(quickCheck.score * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={quickCheck.score * 100} className="h-1.5" />
                      </div>
                    )}

                    {/* Deep AI Analysis */}
                    {deepAnalysis && (
                      <div className="space-y-2 text-xs">
                        <p className="font-medium">🔍 Deep AI Analysis</p>
                        <div className="text-muted-foreground whitespace-pre-wrap">
                          {deepAnalysis}
                        </div>
                      </div>
                    )}

                    {/* Fallback indicators */}
                    {!quickCheck && !deepAnalysis && !isAnalyzing && (
                      <div className="space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Authenticity Score</span>
                          <span className="font-bold text-brand-electric">{verificationScore}%</span>
                        </div>
                        <Progress value={verificationScore} className="h-1.5" />
                        
                        <div className="pt-2 space-y-1">
                          <p className="font-medium">Key Indicators:</p>
                          <div className="flex items-start gap-1.5">
                            <CheckCircle className="w-3 h-3 mt-0.5 text-green-500 flex-shrink-0" />
                            <span className="text-muted-foreground">Multiple verified sources</span>
                          </div>
                          <div className="flex items-start gap-1.5">
                            <CheckCircle className="w-3 h-3 mt-0.5 text-green-500 flex-shrink-0" />
                            <span className="text-muted-foreground">Cross-referenced with fact-checkers</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            <div className="flex items-center gap-2 pt-2">
              <Button 
                size="sm"
                className="flex-1 text-xs"
                onClick={(e) => {
                  e.stopPropagation();
                  setDialogOpen(true);
                }}
              >
                Read Full Article
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handlePlayVideo}
                className="px-2"
              >
                <PlayCircle className="w-3 h-3" />
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleTextToSpeech}
                className="px-2"
              >
                <Volume2 className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <ArticleDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={title}
        summary={summary}
        sources={sources}
        verified={verified}
        timestamp={timestamp}
        imageUrl={imageUrl}
      />
    </>
  );
};

export default DiscoverNewsCard;
