import { Home, Search, Bookmark, User, Settings, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate, useLocation } from "react-router-dom";

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-brand-navy text-white flex flex-col z-50">
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center space-x-2 cursor-pointer" onClick={() => navigate("/")}>
          <div className="w-8 h-8 bg-brand-gradient rounded-lg flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">TatvAI</h1>
            <p className="text-xs text-white/60">AI News Synthesis</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 py-6">
        <nav className="space-y-1 px-3">
          <p className="px-3 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Navigate</p>
          
          <Button
            variant="ghost"
            className={`w-full justify-start ${isActive("/news-feed") ? "text-white bg-white/10" : "text-white/70 hover:text-white hover:bg-white/10"}`}
            onClick={() => navigate("/news-feed")}
          >
            <Home className="w-4 h-4 mr-3" />
            News Feed
          </Button>
          
          <Button
            variant="ghost"
            className={`w-full justify-start ${isActive("/") ? "text-white bg-white/10" : "text-white/70 hover:text-white hover:bg-white/10"}`}
            onClick={() => navigate("/")}
          >
            <Search className="w-4 h-4 mr-3" />
            Discover
          </Button>
          
          <Button
            variant="ghost"
            className={`w-full justify-start ${isActive("/bookmarks") ? "text-white bg-white/10" : "text-white/70 hover:text-white hover:bg-white/10"}`}
            onClick={() => navigate("/bookmarks")}
          >
            <Bookmark className="w-4 h-4 mr-3" />
            Bookmarks
          </Button>
        </nav>

        {/* AI Features */}
        <div className="mt-8 px-3">
          <p className="px-3 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">AI Features</p>
          
          <div className="space-y-3 px-3">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 rounded-full bg-brand-electric"></div>
              <span className="text-sm text-white/80">100+ Sources</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 rounded-full bg-brand-electric"></div>
              <span className="text-sm text-white/80">AI Analysis</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 rounded-full bg-brand-electric"></div>
              <span className="text-sm text-white/80">Multi-language</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="border-t border-white/10 p-3 space-y-1">
        <Button
          variant="ghost"
          className={`w-full justify-start ${isActive("/profile") ? "text-white bg-white/10" : "text-white/70 hover:text-white hover:bg-white/10"}`}
          onClick={() => navigate("/profile")}
        >
          <User className="w-4 h-4 mr-3" />
          Profile
        </Button>
        
        <Button
          variant="ghost"
          className={`w-full justify-start ${isActive("/settings") ? "text-white bg-white/10" : "text-white/70 hover:text-white hover:bg-white/10"}`}
          onClick={() => navigate("/settings")}
        >
          <Settings className="w-4 h-4 mr-3" />
          Settings
        </Button>
      </div>
    </aside>
  );
};

export default Sidebar;
