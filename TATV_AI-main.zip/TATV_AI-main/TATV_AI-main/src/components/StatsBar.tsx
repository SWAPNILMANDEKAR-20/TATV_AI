
import { TrendingUp, Users, Globe, Zap } from "lucide-react";

const StatsBar = () => {
  const stats = [
    { icon: Globe, label: "Active Sources", value: "156", color: "text-brand-electric" },
    { icon: Users, label: "Daily Readers", value: "2.4M", color: "text-news-verified" },
    { icon: TrendingUp, label: "Articles Today", value: "834", color: "text-brand-navy" },
    { icon: Zap, label: "AI Synthesis Speed", value: "2.3s", color: "text-news-urgent" },
  ];

  return (
    <section className="py-8 bg-white border-b border-border">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default StatsBar;
