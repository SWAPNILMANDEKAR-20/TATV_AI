
import NewsCard from "./NewsCard";
import { Button } from "@/components/ui/button";
import { Filter, TrendingUp, Clock, Globe } from "lucide-react";

const NewsFeed = () => {
  const mockNews = [
    {
      title: "Global Climate Summit Reaches Historic Agreement on Carbon Reduction",
      summary: "World leaders at COP29 have agreed to ambitious carbon reduction targets, with 195 countries committing to net-zero emissions by 2040. The agreement includes unprecedented funding for developing nations and breakthrough renewable energy initiatives.",
      sources: 156,
      readTime: "4 min",
      timestamp: "2 hours ago",
      verified: true,
      urgent: true,
      imageUrl: "https://images.unsplash.com/photo-1569163139394-de44cb2c2c90?w=800&h=400&fit=crop"
    },
    {
      title: "Revolutionary AI Breakthrough in Medical Diagnosis",
      summary: "Scientists at Stanford University have developed an AI system that can diagnose rare diseases with 97% accuracy, potentially saving millions of lives through early detection. The system analyzes medical imaging and genetic data simultaneously.",
      sources: 89,
      readTime: "6 min",
      timestamp: "4 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=400&fit=crop"
    },
    {
      title: "Major Economic Indicators Signal Market Shift",
      summary: "Financial analysts report significant changes in global market patterns as emerging technologies drive new investment opportunities. The shift towards sustainable energy and AI infrastructure is reshaping traditional market dynamics.",
      sources: 234,
      readTime: "5 min",
      timestamp: "6 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=400&fit=crop"
    },
    {
      title: "Space Technology Advances Enable Mars Mission Timeline",
      summary: "NASA and private space companies announce accelerated timeline for Mars missions following successful propulsion system tests. New ion drive technology could reduce travel time to Mars by 60%.",
      sources: 78,
      readTime: "3 min",
      timestamp: "8 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800&h=400&fit=crop"
    },
    {
      title: "Quantum Computing Breakthrough: IBM Achieves 1000-Qubit Milestone",
      summary: "IBM researchers successfully demonstrate a 1000-qubit quantum computer capable of solving complex problems exponentially faster than classical computers. This breakthrough marks a significant step toward practical quantum computing applications.",
      sources: 142,
      readTime: "5 min",
      timestamp: "10 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&h=400&fit=crop"
    },
    {
      title: "Global Football Transfer Window Breaks Records with $2.5B Spent",
      summary: "European football clubs shatter spending records during the winter transfer window, with Premier League and La Liga teams leading unprecedented investments in young talent from South America and Africa.",
      sources: 98,
      readTime: "4 min",
      timestamp: "12 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&h=400&fit=crop"
    },
    {
      title: "Breakthrough Cancer Treatment Shows 85% Success Rate in Clinical Trials",
      summary: "A new immunotherapy treatment developed by international researchers demonstrates remarkable efficacy against multiple cancer types. The treatment uses genetically modified T-cells to target and eliminate cancer cells with minimal side effects.",
      sources: 187,
      readTime: "7 min",
      timestamp: "14 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&h=400&fit=crop"
    },
    {
      title: "Asian Markets Surge Following Trade Agreement Announcement",
      summary: "Stock markets across Asia experience significant gains after major economies announce comprehensive trade agreements. The deals are expected to boost GDP growth and create millions of jobs across the region.",
      sources: 215,
      readTime: "4 min",
      timestamp: "16 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=400&fit=crop"
    },
    {
      title: "Electric Vehicle Sales Surpass 50% Market Share in Europe",
      summary: "European automotive industry reaches historic milestone as electric vehicles account for over half of all new car sales. Major manufacturers accelerate transition plans, with several announcing end dates for internal combustion engine production.",
      sources: 167,
      readTime: "5 min",
      timestamp: "18 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=800&h=400&fit=crop"
    },
    {
      title: "Archaeological Discovery Rewrites Ancient Civilization Timeline",
      summary: "Archaeologists in Egypt uncover a previously unknown pyramid complex that predates the Great Pyramid of Giza by 300 years. The discovery includes advanced engineering techniques and artifacts suggesting earlier technological sophistication.",
      sources: 134,
      readTime: "6 min",
      timestamp: "20 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1503375940492-c89b689b7ed2?w=800&h=400&fit=crop"
    },
    {
      title: "Global Food Crisis Averted Through Vertical Farming Innovation",
      summary: "Revolutionary vertical farming technology enables year-round crop production using 95% less water and 99% less land than traditional agriculture. The breakthrough could help feed growing urban populations sustainably.",
      sources: 176,
      readTime: "5 min",
      timestamp: "22 hours ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800&h=400&fit=crop"
    },
    {
      title: "Tennis Legend Announces Retirement After Record-Breaking Career",
      summary: "One of tennis's greatest players announces retirement following an illustrious 20-year career that includes 24 Grand Slam titles and Olympic gold medals. The announcement marks the end of an era in professional tennis.",
      sources: 203,
      readTime: "4 min",
      timestamp: "1 day ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=800&h=400&fit=crop"
    },
    {
      title: "Cybersecurity Experts Warn of Sophisticated New Threat Targeting Financial Institutions",
      summary: "Security researchers identify advanced persistent threat campaign targeting banks and financial services worldwide. New AI-powered defense systems deployed to protect critical infrastructure and customer data.",
      sources: 145,
      readTime: "6 min",
      timestamp: "1 day ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=400&fit=crop"
    },
    {
      title: "Renewable Energy Surpasses Fossil Fuels in Global Power Generation",
      summary: "Historic milestone reached as renewable energy sources generate more electricity than fossil fuels for the first time globally. Solar and wind installations continue rapid expansion driven by falling costs and policy support.",
      sources: 198,
      readTime: "5 min",
      timestamp: "1 day ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800&h=400&fit=crop"
    },
    {
      title: "Streaming Platform Announces Original Content Investment of $15 Billion",
      summary: "Major streaming service reveals unprecedented investment in original programming across 50 countries. The initiative includes support for independent filmmakers and diverse storytelling from underrepresented communities.",
      sources: 112,
      readTime: "4 min",
      timestamp: "1 day ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1616530940355-351fabd9524b?w=800&h=400&fit=crop"
    },
    {
      title: "Ocean Cleanup Project Removes 100,000 Tons of Plastic from Pacific",
      summary: "Environmental initiative celebrates major milestone in ocean conservation efforts. Advanced cleanup systems have successfully removed massive amounts of plastic waste from the Great Pacific Garbage Patch, with plans to expand operations globally.",
      sources: 189,
      readTime: "5 min",
      timestamp: "2 days ago",
      verified: true,
      imageUrl: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?w=800&h=400&fit=crop"
    }
  ];

  return (
    <section className="py-12 bg-gradient-to-br from-background to-muted/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2">Latest Synthesis</h2>
            <p className="text-muted-foreground">AI-curated news from verified global sources</p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => console.log("Filter clicked")}>
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm" onClick={() => console.log("Trending clicked")}>
              <TrendingUp className="w-4 h-4 mr-2" />
              Trending
            </Button>
            <Button variant="outline" size="sm" onClick={() => console.log("Recent clicked")}>
              <Clock className="w-4 h-4 mr-2" />
              Recent
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {mockNews.map((news, index) => (
            <NewsCard key={index} {...news} />
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" className="btn-primary" onClick={() => console.log("Load More Stories clicked")}>
            Load More Stories
          </Button>
        </div>
      </div>
    </section>
  );
};

export default NewsFeed;
