
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Globe, BarChart3 } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="hero-section py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-br from-brand-navy/90 to-brand-electric/80"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="animate-fade-in">
            <h1 className="headline text-white mb-6">
              AI-Powered News Synthesis for the
              <span className="text-brand-light block mt-2">Modern World</span>
            </h1>
            
            <p className="body-large text-white/90 mb-8 max-w-2xl mx-auto">
              Get comprehensive, verified news articles synthesized from over 100 trusted sources. 
              Complete with AI explainer videos, predictive analysis, and personalized insights.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button size="lg" className="btn-hero group" onClick={() => console.log("Start Reading clicked")}>
                Start Reading
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button variant="outline" size="lg" className="btn-hero" onClick={() => console.log("Watch Demo clicked")}>
                Watch Demo
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-slide-up">
            <div className="glass-card p-6 text-center">
              <Zap className="w-8 h-8 text-brand-light mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">AI Synthesis</h3>
              <p className="text-white/80 text-sm">
                Intelligent analysis from 100+ verified sources
              </p>
            </div>
            
            <div className="glass-card p-6 text-center">
              <Globe className="w-8 h-8 text-brand-light mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Global Coverage</h3>
              <p className="text-white/80 text-sm">
                Real-time news from every corner of the world
              </p>
            </div>
            
            <div className="glass-card p-6 text-center">
              <BarChart3 className="w-8 h-8 text-brand-light mx-auto mb-3" />
              <h3 className="font-semibold text-white mb-2">Predictive Insights</h3>
              <p className="text-white/80 text-sm">
                Future analysis and trend predictions
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
