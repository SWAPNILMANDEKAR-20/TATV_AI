import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Clock, Eye, PlayCircle, Volume2, ExternalLink, CheckCircle, Brain, TrendingUp, ShieldCheck } from "lucide-react";
import { useState } from "react";
import ArticleDialog from "./ArticleDialog";

interface NewsCardProps {
  title: string;
  summary: string;
  sources: number;
  readTime: string;
  timestamp: string;
  verified: boolean;
  urgent?: boolean;
  imageUrl?: string;
}

const NewsCard = ({ 
  title, 
  summary, 
  sources, 
  readTime, 
  timestamp, 
  verified, 
  urgent = false,
  imageUrl 
}: NewsCardProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [showAISummary, setShowAISummary] = useState(false);
  const [showAIPrediction, setShowAIPrediction] = useState(false);
  const [showCredibility, setShowCredibility] = useState(false);
  
  // Generate random credibility score between 84-96%
  const credibilityScore = Math.floor(Math.random() * (96 - 84 + 1)) + 84;

  const handlePlayVideo = () => {
    console.log("Playing AI explainer video for:", title);
  };

  const handleTextToSpeech = () => {
    console.log("Starting text-to-speech for:", title);
  };

  return (
    <div className="news-card group">
      {imageUrl && (
        <div className="mb-4 rounded-lg overflow-hidden">
          <img 
            src={imageUrl} 
            alt={title}
            className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
      )}

      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-2">
          {verified && (
            <Badge className="verified-badge">
              <CheckCircle className="w-3 h-3 mr-1" />
              Verified
            </Badge>
          )}
          {urgent && (
            <Badge className="urgent-badge">
              Breaking
            </Badge>
          )}
        </div>
        <div className="flex items-center space-x-1 text-sm text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>{timestamp}</span>
        </div>
      </div>

      <h3 className="subheadline mb-3 text-foreground group-hover:text-brand-electric transition-colors">
        {title}
      </h3>

      <p className="text-muted-foreground mb-4 leading-relaxed">
        {summary}
      </p>

      <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
        <div className="flex items-center space-x-4">
          <span className="flex items-center">
            <ExternalLink className="w-3 h-3 mr-1" />
            {sources} sources
          </span>
          <span className="flex items-center">
            <Eye className="w-3 h-3 mr-1" />
            {readTime} read
          </span>
        </div>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex items-center gap-2">
          <Button 
            size="sm" 
            variant="outline"
            className="flex-1"
            onClick={() => setShowAISummary(!showAISummary)}
          >
            <Brain className="w-4 h-4 mr-2" />
            AI Summary
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            className="flex-1"
            onClick={() => setShowAIPrediction(!showAIPrediction)}
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            AI Prediction
          </Button>
        </div>

        {showAISummary && (
          <div className="p-4 rounded-lg bg-muted/50 border animate-in fade-in-50 slide-in-from-top-2">
            <h4 className="font-semibold mb-2 flex items-center">
              <Brain className="w-4 h-4 mr-2 text-brand-electric" />
              AI Summary
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              This article discusses {title.toLowerCase()}. Our AI analysis indicates this is a significant development 
              with potential implications across multiple sectors. Key facts have been verified across {sources} independent sources.
            </p>
          </div>
        )}

        {showAIPrediction && (
          <div className="p-4 rounded-lg bg-muted/50 border animate-in fade-in-50 slide-in-from-top-2">
            <h4 className="font-semibold mb-2 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2 text-brand-electric" />
              AI Prediction
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Based on current trends and historical data, this development is likely to have lasting impact. 
              Our predictive models suggest increased activity in related sectors over the coming weeks.
            </p>
          </div>
        )}
      </div>

      <div className="mb-4">
        <Button 
          size="sm" 
          variant="outline"
          className="w-full"
          onClick={() => setShowCredibility(!showCredibility)}
        >
          <ShieldCheck className="w-4 h-4 mr-2" />
          Credibility Analysis
        </Button>

        {showCredibility && (
          <div className="mt-3 p-4 rounded-lg bg-gradient-to-br from-background to-muted/30 border animate-in fade-in-50 slide-in-from-top-2">
            <div className="flex items-start gap-3 mb-4">
              <div className="p-2 rounded-lg bg-brand-electric/10">
                <ShieldCheck className="w-5 h-5 text-brand-electric" />
              </div>
              <div>
                <h4 className="font-semibold">Credibility Analysis</h4>
                <p className="text-xs text-muted-foreground">AI-powered fake news detection</p>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Overall Credibility</span>
                <span className="text-2xl font-bold text-brand-electric">{credibilityScore}%</span>
              </div>
              <Progress value={credibilityScore} className="h-2" />
            </div>

            <div>
              <h5 className="text-sm font-medium mb-3">Key Indicators</h5>
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                  <span className="text-muted-foreground">Cross-verified with multiple sources</span>
                </div>
                <div className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                  <span className="text-muted-foreground">Consistent with established facts</span>
                </div>
                <div className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                  <span className="text-muted-foreground">Published by reliable sources</span>
                </div>
                <div className="flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                  <span className="text-muted-foreground">Recent and up-to-date information</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center space-x-2">
        <Button 
          size="sm" 
          className="btn-primary flex-1"
          onClick={() => setDialogOpen(true)}
        >
          Read Full Analysis
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={handlePlayVideo}
          className="px-3"
        >
          <PlayCircle className="w-4 h-4" />
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={handleTextToSpeech}
          className="px-3"
        >
          <Volume2 className="w-4 h-4" />
        </Button>
      </div>

      <ArticleDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={title}
        summary={summary}
        sources={sources}
        verified={verified}
        timestamp={timestamp}
        imageUrl={imageUrl}
      />
    </div>
  );
};

export default NewsCard;
