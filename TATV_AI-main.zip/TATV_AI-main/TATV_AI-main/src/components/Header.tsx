
import { Button } from "@/components/ui/button";
import { Search, Globe, User, Menu } from "lucide-react";
import { useState } from "react";

const Header = () => {
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-brand-gradient rounded-lg flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gradient">TatvAI</h1>
          </div>

          {/* Search Bar */}
          <div className={`hidden md:flex items-center bg-muted rounded-full px-4 py-2 transition-all duration-300 ${isSearchFocused ? 'ring-2 ring-brand-electric/50 bg-white shadow-lg' : ''}`}>
            <Search className="w-4 h-4 text-muted-foreground mr-2" />
            <input
              type="text"
              placeholder="Search news, topics, or incidents..."
              className="bg-transparent border-0 outline-none flex-1 text-sm"
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setIsSearchFocused(false)}
            />
          </div>

          {/* Navigation */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="hidden md:flex" onClick={() => console.log("Live Feed clicked")}>
              Live Feed
            </Button>
            <Button variant="ghost" size="sm" className="hidden md:flex" onClick={() => console.log("Analysis clicked")}>
              Analysis
            </Button>
            <Button variant="ghost" size="icon" onClick={() => console.log("User profile clicked")}>
              <User className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => console.log("Menu clicked")}>
              <Menu className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
