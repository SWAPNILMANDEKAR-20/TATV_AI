import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Shield, CheckCircle } from "lucide-react";
import { useState } from "react";

interface ArticleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  summary: string;
  sources: number;
  verified: boolean;
  timestamp: string;
  imageUrl?: string;
}

const ArticleDialog = ({
  open,
  onOpenChange,
  title,
  summary,
  sources,
  verified,
  timestamp,
  imageUrl
}: ArticleDialogProps) => {
  const [showAISummary, setShowAISummary] = useState(false);
  const [showPrediction, setShowPrediction] = useState(false);
  
  const fakeNewsScore = Math.floor(Math.random() * (96 - 84 + 1)) + 84;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between mb-4">
            <DialogTitle className="text-2xl font-bold text-foreground pr-8">
              {title}
            </DialogTitle>
          </div>
          
          <div className="flex items-center gap-3 mb-4">
            {verified && (
              <Badge className="verified-badge">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            )}
            <Badge variant="outline" className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              {fakeNewsScore}% Authentic
            </Badge>
            <span className="text-sm text-muted-foreground">{timestamp}</span>
          </div>
        </DialogHeader>

        {imageUrl && (
          <div className="mb-6 rounded-lg overflow-hidden">
            <img 
              src={imageUrl} 
              alt={title}
              className="w-full h-64 object-cover"
            />
          </div>
        )}

        <div className="space-y-6">
          <div className="bg-muted/50 p-4 rounded-lg border border-border">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-foreground">Authenticity Analysis</h3>
              <Badge variant={fakeNewsScore >= 90 ? "default" : "secondary"}>
                <Shield className="w-3 h-3 mr-1" />
                {fakeNewsScore}% Real
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              Based on {sources} verified sources and cross-referencing with our AI fact-checking system.
              {fakeNewsScore >= 90 ? " Highly reliable." : " Generally trustworthy."}
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-3">Full Analysis</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">{summary}</p>
            <p className="text-muted-foreground leading-relaxed mb-4">
              This comprehensive analysis synthesizes information from {sources} verified news sources, 
              providing you with a balanced and fact-checked perspective on the incident. Our AI engine 
              has cross-referenced multiple reports to ensure accuracy and eliminate bias.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button 
              onClick={() => setShowAISummary(!showAISummary)}
              className="flex-1"
              variant={showAISummary ? "default" : "outline"}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              AI Summary
            </Button>
            <Button 
              onClick={() => setShowPrediction(!showPrediction)}
              className="flex-1"
              variant={showPrediction ? "default" : "outline"}
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              AI Prediction
            </Button>
          </div>

          {showAISummary && (
            <div className="bg-primary/5 p-4 rounded-lg border border-primary/20 animate-in fade-in slide-in-from-top-2">
              <h4 className="font-semibold text-foreground mb-2 flex items-center">
                <Sparkles className="w-4 h-4 mr-2 text-primary" />
                AI-Generated Summary
              </h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Our AI has condensed the key points: {summary.slice(0, 150)}... 
                The situation is being monitored closely with updates from reliable sources providing 
                continuous coverage of developments.
              </p>
            </div>
          )}

          {showPrediction && (
            <div className="bg-accent/5 p-4 rounded-lg border border-accent/20 animate-in fade-in slide-in-from-top-2">
              <h4 className="font-semibold text-foreground mb-2 flex items-center">
                <TrendingUp className="w-4 h-4 mr-2 text-accent" />
                Predictive Analysis
              </h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Based on historical patterns and current trends, our AI predicts this story will continue 
                to develop over the next 24-48 hours. Related topics and follow-up coverage are expected 
                from major news outlets. Confidence level: High.
              </p>
            </div>
          )}

          <div className="text-xs text-muted-foreground pt-4 border-t border-border">
            Sources: {sources} verified outlets • Last updated: {timestamp}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ArticleDialog;
