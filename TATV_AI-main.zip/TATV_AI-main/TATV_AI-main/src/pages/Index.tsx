import Sidebar from "@/components/Sidebar";
import Discover from "./Discover";
import NewsFeed from "./NewsFeed";
import Bookmarks from "./Bookmarks";
import { useLocation } from "react-router-dom";

const Index = () => {
  const location = useLocation();

  const renderContent = () => {
    switch (location.pathname) {
      case "/news-feed":
        return <NewsFeed />;
      case "/bookmarks":
        return <Bookmarks />;
      default:
        return <Discover />;
    }
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 ml-64">
        {renderContent()}
      </main>
    </div>
  );
};

export default Index;
