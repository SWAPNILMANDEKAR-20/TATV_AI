import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import DiscoverNewsCard from "@/components/DiscoverNewsCard";
import { useBookmarks } from "@/contexts/BookmarkContext";
import { useState } from "react";

const Bookmarks = () => {
  const { bookmarks } = useBookmarks();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredBookmarks = bookmarks.filter(news => {
    const matchesSearch = searchQuery === "" || 
                         news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         news.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto p-8">
        {/* Header */}
        <div className="mb-8">
          <div className="mb-4">
            <h1 className="text-4xl font-bold mb-2">Bookmarked Articles</h1>
            <p className="text-muted-foreground">Your saved articles for later reading</p>
          </div>

          {/* Search Bar */}
          {bookmarks.length > 0 && (
            <div className="relative mb-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search bookmarked articles..."
                className="pl-12 h-14 text-base"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          )}
        </div>

        {/* Empty State */}
        {bookmarks.length === 0 ? (
          <div className="text-center py-20">
            <div className="mb-4">
              <svg
                className="w-24 h-24 mx-auto text-muted-foreground/30"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-semibold mb-2">No bookmarks yet</h3>
            <p className="text-muted-foreground">
              Start bookmarking articles you want to read later
            </p>
          </div>
        ) : (
          <>
            {/* Results Count */}
            <p className="text-sm text-muted-foreground mb-6">
              {filteredBookmarks.length} bookmarked {filteredBookmarks.length === 1 ? 'article' : 'articles'}
            </p>

            {/* News Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBookmarks.map((news) => (
                <DiscoverNewsCard key={news.id} {...news} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Bookmarks;
