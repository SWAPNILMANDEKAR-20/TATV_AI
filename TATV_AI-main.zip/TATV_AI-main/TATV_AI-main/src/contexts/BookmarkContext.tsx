import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  category: string;
  imageUrl: string;
  verificationScore: number;
  sources: number;
  readTime: string;
  timestamp: string;
  verified: boolean;
  urgent?: boolean;
  trending?: boolean;
}

interface BookmarkContextType {
  bookmarks: NewsItem[];
  addBookmark: (item: NewsItem) => void;
  removeBookmark: (id: string) => void;
  isBookmarked: (id: string) => boolean;
}

const BookmarkContext = createContext<BookmarkContextType | undefined>(undefined);

export const BookmarkProvider = ({ children }: { children: ReactNode }) => {
  const [bookmarks, setBookmarks] = useState<NewsItem[]>(() => {
    const saved = localStorage.getItem("newsBookmarks");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("newsBookmarks", JSON.stringify(bookmarks));
  }, [bookmarks]);

  const addBookmark = (item: NewsItem) => {
    setBookmarks(prev => [...prev, item]);
  };

  const removeBookmark = (id: string) => {
    setBookmarks(prev => prev.filter(item => item.id !== id));
  };

  const isBookmarked = (id: string) => {
    return bookmarks.some(item => item.id === id);
  };

  return (
    <BookmarkContext.Provider value={{ bookmarks, addBookmark, removeBookmark, isBookmarked }}>
      {children}
    </BookmarkContext.Provider>
  );
};

export const useBookmarks = () => {
  const context = useContext(BookmarkContext);
  if (!context) {
    throw new Error("useBookmarks must be used within BookmarkProvider");
  }
  return context;
};
