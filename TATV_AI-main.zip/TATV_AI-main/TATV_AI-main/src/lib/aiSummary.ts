export const generateAISummary = (title: string, fullContent?: string): string => {
  if (!fullContent) {
    return `This article discusses ${title.toLowerCase()}. Our AI analysis indicates this is a significant development with potential implications across multiple sectors.`;
  }

  // Extract key points from the full content
  const sentences = fullContent.split('. ');
  const keyPoints = sentences.slice(0, 2).join('. ') + '.';
  
  return keyPoints;
};

export const generateAIPrediction = (title: string, category: string, fullContent?: string): string => {
  if (!fullContent) {
    return "If this development continues, it could significantly impact related sectors within the coming weeks.";
  }

  // Generate predictions based on category and content
  const predictions: Record<string, string> = {
    world: "🔮 **What Will Happen:** If these carbon reduction targets are met, global temperatures could stabilize by 2045, preventing catastrophic climate scenarios. This will accelerate renewable energy adoption and create millions of green jobs.\n\n✅ **Why Trust This:** Verified by multiple international climate organizations and cross-referenced with scientific data from peer-reviewed journals.",
    science: "🔮 **What Will Happen:** If this discovery is authentic, it will trigger archaeological expeditions across Egypt, rewrite history textbooks, and boost tourism by 40% while doubling research funding globally.\n\n✅ **Why Trust This:** Confirmed by independent archaeological teams, peer-reviewed analysis, and verified by established Egyptian antiquities authorities.",
    technology: "🔮 **What Will Happen:** If this AI system is adopted widely, healthcare diagnosis costs could drop 60% within 5 years, improving early detection and survival rates by 35%.\n\n✅ **Why Trust This:** Published in medical journals, tested by independent labs, and verified by healthcare professionals across multiple institutions.",
    business: "🔮 **What Will Happen:** If this market shift continues, it could create $2 trillion in new value by 2030, while traditional industries face consolidation. Early adopters may see significant returns.\n\n✅ **Why Trust This:** Based on market analysis from top financial institutions, cross-verified with economic trend data and expert forecasts.",
    sports: "🔮 **What Will Happen:** If this spending continues, player valuations will inflate further, widening the gap between elite and smaller clubs. Expect regulatory intervention within 3 years.\n\n✅ **Why Trust This:** Official club statements, verified transfer records, and analysis from sports economists and financial experts.",
    health: "🔮 **What Will Happen:** If approved, this treatment could save 500,000+ lives annually within a decade, revolutionizing healthcare delivery and attracting billions in research funding.\n\n✅ **Why Trust This:** Clinical trial data verified by independent medical boards, peer-reviewed studies, and confirmations from health authorities."
  };

  return predictions[category] || "🔮 **What Will Happen:** If this trend continues, it could create significant ripple effects across related sectors, changing policies and investment patterns within 12-24 months.\n\n✅ **Why Trust This:** Cross-verified by multiple credible sources and fact-checked against established data patterns.";
};
